# 🚀 Начало импорта калькуляторов из calc1

## Подготовка

✅ Скрипт импорта готов  
✅ Маппинг категорий настроен  
✅ Валидация настроена  

## Структура calc1.ru

Найдено **11 категорий** с **~87 калькуляторами**:

1. **finance** (8) → `finance`
2. **math** (9) → `math`
3. **life** (8) → `everyday`
4. **construction** (8) → `engineering`
5. **auto** (8) → `everyday`
6. **time** (8) → `everyday`
7. **health** (8) → `everyday`
8. **science** (8) → `math`
9. **converter** (8) → `everyday`
10. **fun** (8) → `everyday`
11. **it** (6) → `engineering`

## Команды для импорта

### Вариант 1: Импорт по одной категории (рекомендуется)

```bash
# 1. Математика (9 калькуляторов)
npm run import:calc1 <путь-к-calc1> --category math

# 2. Финансы (8 калькуляторов)
npm run import:calc1 <путь-к-calc1> --category finance

# 3. Повседневные - life (8 калькуляторов)
npm run import:calc1 <путь-к-calc1> --category everyday

# 4. Инженерия - construction (8 калькуляторов)
npm run import:calc1 <путь-к-calc1> --category engineering
```

### Вариант 2: Тестовый режим (dry-run)

```bash
# Проверка без записи файлов
npm run import:calc1 <путь-к-calc1> --category math --dry-run
```

## Что происходит при импорте

1. ✅ Скрипт находит калькуляторы в calc1
2. ✅ Фильтрует по категории (если указана)
3. ✅ Парсит структуру и контент
4. ✅ Нормализует (имена, единицы)
5. ✅ Создает файлы:
   - `data/calculators/<slug>.json` (структура)
   - `locales/en/calculators/items/<slug>.json` (контент)
6. ✅ Запускает валидацию после каждой категории

## Проверка после импорта

После каждой категории проверяйте:

```bash
# Автоматически запускается, но можно вручную:
npm run i18n:validate
```

Должно быть: `✅ All validations passed!`

## Пример запуска

```bash
# Замените <путь-к-calc1> на реальный путь, например:
npm run import:calc1 C:\projects\calc1 --category math
```

## Следующие шаги

1. Укажите путь к локальной копии calc1
2. Начните с категории `math` (тестовый импорт)
3. Проверьте результат
4. Продолжайте по остальным категориям

---

**Готов к импорту!** Укажите путь к calc1 для начала.

