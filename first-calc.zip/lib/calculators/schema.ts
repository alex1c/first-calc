/**
 * DSL/JSON Schema for calculator definitions
 * Allows creating calculators without modifying React components
 */

/**
 * Calculator Schema (structure only, no texts)
 * Texts are loaded from locales/{locale}/calculators/items/{slug}.json
 */
export interface CalculatorSchema {
	id: string
	category: string
	slug: string
	inputs: Array<{
		name: string
		type: 'number' | 'text' | 'select'
		unit?: string
		min?: number
		max?: number
		step?: number
		options?: Array<{ value: string; label: string }>
		defaultValue?: number | string
	}>
	outputs: Array<{
		name: string
	}>
	formula: string // e.g., "value * percent / 100"
	variables?: Record<string, string> // Variable descriptions
	relatedIds?: string[]
	standardIds?: string[]
	isEnabled?: boolean // Soft disable flag (default: true)
}

/**
 * Validate calculator schema
 */
export function validateCalculatorSchema(schema: unknown): {
	valid: boolean
	errors: string[]
} {
	const errors: string[] = []

	if (!schema || typeof schema !== 'object') {
		return { valid: false, errors: ['Schema must be an object'] }
	}

	const s = schema as Partial<CalculatorSchema>

	// Required fields
	if (!s.id || typeof s.id !== 'string') {
		errors.push('id is required and must be a string')
	}
	// locale is optional in schema (it's passed as parameter to schemaToDefinition)
	// if (s.locale && typeof s.locale !== 'string') {
	// 	errors.push('locale must be a string if provided')
	// }
	if (!s.category || typeof s.category !== 'string') {
		errors.push('category is required and must be a string')
	}
	if (!s.slug || typeof s.slug !== 'string') {
		errors.push('slug is required and must be a string')
	}
	// title and description are loaded from items files (T-серия), not required in schema
	// if (!s.title || typeof s.title !== 'string') {
	// 	errors.push('title is required and must be a string')
	// }
	// if (!s.description || typeof s.description !== 'string') {
	// 	errors.push('description is required and must be a string')
	// }

	// Inputs validation
	if (!Array.isArray(s.inputs) || s.inputs.length === 0) {
		errors.push('inputs is required and must be a non-empty array')
	} else {
		s.inputs.forEach((input, index) => {
			if (!input.name || typeof input.name !== 'string') {
				errors.push(`inputs[${index}].name is required`)
			}
			// label is loaded from items files (T-серия), not required in schema
			// if (!input.label || typeof input.label !== 'string') {
			// 	errors.push(`inputs[${index}].label is required`)
			// }
			if (!['number', 'text', 'select'].includes(input.type)) {
				errors.push(`inputs[${index}].type must be "number", "text", or "select"`)
			}
			if (input.type === 'select' && !input.options) {
				errors.push(`inputs[${index}].options is required for select type`)
			}
		})
	}

	// Outputs validation
	if (!Array.isArray(s.outputs) || s.outputs.length === 0) {
		errors.push('outputs is required and must be a non-empty array')
	} else {
		s.outputs.forEach((output, index) => {
			if (!output.name || typeof output.name !== 'string') {
				errors.push(`outputs[${index}].name is required`)
			}
			// label is loaded from items files (T-серия), not required in schema
			// if (!output.label || typeof output.label !== 'string') {
			// 	errors.push(`outputs[${index}].label is required`)
			// }
		})
	}

	// Formula validation
	if (!s.formula || typeof s.formula !== 'string') {
		errors.push('formula is required and must be a string')
	}

	return {
		valid: errors.length === 0,
		errors,
	}
}

/**
 * Parse formula string and execute calculation
 * Supports basic math operations: +, -, *, /, %, **, Math functions
 */
export function executeFormula(
	formula: string,
	variables: Record<string, number>,
): number {
	// Create safe evaluation context
	const context: Record<string, number> = {
		...variables,
		Math,
		PI: Math.PI,
		E: Math.E,
	}

	// Replace variable names with their values
	let expression = formula
	for (const [key, value] of Object.entries(variables)) {
		// Replace whole word matches only
		const regex = new RegExp(`\\b${key}\\b`, 'g')
		expression = expression.replace(regex, String(value))
	}

	// Evaluate safely (in production, consider using a proper expression parser)
	try {
		// eslint-disable-next-line no-eval
		const result = eval(expression)
		if (typeof result !== 'number' || !Number.isFinite(result)) {
			throw new Error('Formula result is not a valid number')
		}
		return result
	} catch (error) {
		throw new Error(
			`Formula evaluation failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
		)
	}
}

/**
 * Convert CalculatorSchema to CalculatorDefinition
 * Loads content from locales/{locale}/calculators/items/{slug}.json
 * Falls back to autogen if content not found
 */
export async function schemaToDefinition(
	schema: CalculatorSchema,
	locale: string = 'en',
): Promise<import('@/lib/calculators/types').CalculatorDefinition> {
	// Load content from items file
	const { loadCalculatorContent, getDefaultCalculatorContent } = await import(
		'@/lib/i18n/loadItemContent'
	)
	const { content, contentLocale } = await loadCalculatorContent(locale as any, schema.slug)
	const defaults = getDefaultCalculatorContent(schema.slug)

	// Use content from items file, fallback to defaults
	const title = content?.title || defaults.title || schema.slug
	const shortDescription = content?.shortDescription || defaults.shortDescription || ''
	const longDescription = content?.longDescription || content?.shortDescription || shortDescription
	const howTo = content?.howTo || defaults.howTo || []
	const examples = content?.examples || []
	const faq = content?.faq || []
	const seo = content?.seo

	// Log if using fallback
	if (!content) {
		console.warn(
			`[i18n] Calculator content not found for "${schema.slug}" (locale: ${locale}), using defaults`,
		)
	}
	const { formula, variables, ...rest } = schema

	// Create calculate function from formula
	// Check if formula is valid (not code or object)
	const isValidFormula = formula && 
		typeof formula === 'string' && 
		formula.trim().length > 0 &&
		!formula.includes('export') &&
		!formula.includes('type') &&
		!formula.includes('interface') &&
		!formula.includes('function') &&
		!formula.startsWith('{') &&
		!formula.includes('\r\n *')

	const calculate: import('@/lib/calculators/types').CalculatorFunction = (
		inputs,
	) => {
		// Convert inputs to numbers
		const numericInputs: Record<string, number> = {}
		for (const [key, value] of Object.entries(inputs)) {
			const numValue = Number(value)
			if (isNaN(numValue)) {
				throw new Error(`Invalid number for input: ${key}`)
			}
			numericInputs[key] = numValue
		}

		// Execute formula for each output
		const results: Record<string, number | string> = {}
		for (const output of schema.outputs) {
			try {
				if (isValidFormula) {
					// Use the formula
					const result = executeFormula(formula, numericInputs)
					results[output.name] = result
				} else {
					// Fallback: use first input value or 0
					const firstInputName = schema.inputs[0]?.name
					if (firstInputName && numericInputs[firstInputName] !== undefined) {
						results[output.name] = numericInputs[firstInputName]
					} else {
						results[output.name] = 0
					}
				}
			} catch (error) {
				// Fallback to first input value
				const firstInputName = schema.inputs[0]?.name
				if (firstInputName && numericInputs[firstInputName] !== undefined) {
					results[output.name] = numericInputs[firstInputName]
				} else {
					results[output.name] = 0
				}
			}
		}

		return results
	}

	// Convert inputs - use labels from content if available
	const calculatorInputs: import('@/lib/calculators/types').CalculatorInput[] =
		schema.inputs.map((input, index) => {
			const contentInput = content?.inputs?.[index]
			return {
				name: input.name,
				label: contentInput?.label || input.name,
				type: input.type === 'select' ? 'select' : 'number',
				unitLabel: contentInput?.unitLabel || input.unit,
				placeholder: contentInput?.placeholder || `Enter ${input.name}`,
				options: input.options,
				min: input.min,
				max: input.max,
				step: input.step,
				defaultValue: input.defaultValue,
				helpText: contentInput?.helpText,
				validation: {
					required: true,
					min: input.min,
					max: input.max,
				},
			}
		})

	// Convert outputs - use labels from content if available
	const calculatorOutputs: import('@/lib/calculators/types').CalculatorOutput[] =
		schema.outputs.map((output, index) => {
			const contentOutput = content?.outputs?.[index]
			return {
				name: output.name,
				label: contentOutput?.label || output.name,
				unitLabel: contentOutput?.unitLabel,
				formatType: 'number' as const,
			}
		})

	// Convert examples from content
	const calculatorExamples: import('@/lib/calculators/types').CalculatorExample[] =
		examples.map((example, index) => ({
			id: `example-${index + 1}`,
			title: example.title || `Example ${index + 1}`,
			inputDescription: example.description || 'Calculation example',
			steps: example.steps || [],
			resultDescription: example.resultDescription || '',
		}))

	// Convert FAQ from content
	const calculatorFaq: import('@/lib/calculators/types').CalculatorFaqItem[] = faq

	return {
		id: schema.id,
		slug: schema.slug,
		category: schema.category as import('@/lib/calculators/types').CalculatorCategory,
		title,
		shortDescription,
		longDescription,
		locale: locale as import('@/lib/calculators/types').CalculatorLocale,
		contentLocale: contentLocale as import('@/lib/calculators/types').CalculatorLocale,
		inputs: calculatorInputs,
		outputs: calculatorOutputs,
		calculate,
		howToBullets: howTo,
		examples: calculatorExamples,
		faq: calculatorFaq,
		relatedIds: schema.relatedIds,
		standardIds: schema.standardIds,
		isEnabled: schema.isEnabled !== false, // Default to true if not specified
		meta: seo
			? {
					keywords: seo.keywords,
				}
			: undefined,
	}
}

/**
 * Load calculator schema from JSON file
 * Note: This function only works on the server side (Node.js environment)
 */
export async function loadCalculatorSchema(
	filePath: string,
): Promise<CalculatorSchema> {
	// Check if we're on the server side
	if (typeof window !== 'undefined') {
		throw new Error(
			'loadCalculatorSchema can only be used on the server side',
		)
	}

	try {
		// Dynamic import to ensure this only runs on server
		const fs = await import('fs/promises')
		const path = await import('path')
		
		// Resolve path relative to project root
		const resolvedPath = path.resolve(process.cwd(), filePath)
		const content = await fs.readFile(resolvedPath, 'utf-8')
		const schema = JSON.parse(content) as CalculatorSchema

		const validation = validateCalculatorSchema(schema)
		if (!validation.valid) {
			throw new Error(`Invalid schema: ${validation.errors.join(', ')}`)
		}

		return schema
	} catch (error) {
		throw new Error(
			`Failed to load calculator schema: ${error instanceof Error ? error.message : 'Unknown error'}`,
		)
	}
}




