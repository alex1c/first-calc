/**
 * Calculator categories configuration
 * 
 * Defines stable categories with icons, order, and mapping from old calc1 categories
 */

export interface CategoryConfig {
	id: string
	iconKey: string
	order: number
	displayName: string
}

/**
 * Stable category list with order and icons
 */
export const CATEGORIES: CategoryConfig[] = [
	{
		id: 'math',
		iconKey: '🔢',
		order: 1,
		displayName: 'Mathematics',
	},
	{
		id: 'finance',
		iconKey: '💰',
		order: 2,
		displayName: 'Finance',
	},
	{
		id: 'geometry',
		iconKey: '📐',
		order: 3,
		displayName: 'Geometry',
	},
	{
		id: 'everyday',
		iconKey: '📱',
		order: 4,
		displayName: 'Everyday',
	},
	{
		id: 'engineering',
		iconKey: '⚙️',
		order: 5,
		displayName: 'Engineering',
	},
	{
		id: 'business',
		iconKey: '📊',
		order: 6,
		displayName: 'Business',
	},
]

/**
 * Get category by ID
 */
export function getCategory(id: string): CategoryConfig | undefined {
	return CATEGORIES.find((cat) => cat.id === id)
}

/**
 * Get all category IDs in order
 */
export function getCategoryIds(): string[] {
	return CATEGORIES.sort((a, b) => a.order - b.order).map((cat) => cat.id)
}

/**
 * Get category icon
 */
export function getCategoryIcon(categoryId: string): string {
	const category = getCategory(categoryId)
	return category?.iconKey || '📋'
}

/**
 * Get category display name
 */
export function getCategoryDisplayName(categoryId: string): string {
	const category = getCategory(categoryId)
	return category?.displayName || categoryId
}

