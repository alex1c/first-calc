# PROMPT: Create Eurocode 1 Hub Page

## TASK OVERVIEW
Create an engineering context hub page for Eurocode 1 (EN 1991 – Actions on Structures) at `/standards/eu/eurocode-1`. This page acts as an ENGINEERING CONTEXT HUB that explains structural loads, shows why load assumptions matter, and connects load concepts to foundation and slab calculations. This is NOT a copy of the standard—it is an explanatory, educational hub.

## TARGET URL
`/standards/eu/eurocode-1`

## CATEGORY
Standards → Construction

---

## 1. UPDATE STANDARD DEFINITION

**File:** `data/standards.ts`

Update the existing Eurocode 1 entry (id: 'eurocode-1', country: 'EU', locale: 'en') with:

- **title:** "Eurocode 1 (EN 1991) – Structural Loads Explained"
- **shortDescription:** "Learn how Eurocode 1 defines structural loads and how load principles relate to foundation, slab, and reinforcement calculations."
- **longDescription:** A comprehensive hub-style description explaining:
  - What Eurocode 1 defines (structural loads and actions on structures)
  - Why loads are fundamental in construction (they determine foundation size, slab thickness, reinforcement)
  - How loads affect foundations, slabs, and reinforcement
  - That this page is an educational hub, not a legal document
  - How load assumptions connect to practical calculations
- **Remove formulas and tables** (set to empty arrays or undefined) - this is a hub, not a technical reference
- **relatedCalculatorIds:** Add these calculator IDs:
  - "slab-foundation-calculator"
  - "foundation-volume-calculator"
  - "concrete-volume-calculator"
  - "rebar-calculator"
  - "rebar-weight-calculator"
  - "stair-calculator"
- **meta.keywords:** Include: ["eurocode 1", "EN 1991", "structural loads", "actions on structures", "dead load", "live load", "snow load", "wind load", "foundation design", "construction standards"]

---

## 2. UPDATE STANDARD PAGE COMPONENT

**File:** `app/[locale]/(main)/standards/[country]/[standardSlug]/page.tsx`

Ensure the page detects hub-style standards (those without formulas/tables) and renders hub content. The component should already support this from the Eurocode 2 implementation.

### Hub Page Structure:

**H1:** Use `standard.title` (already set to "Eurocode 1 (EN 1991) – Structural Loads Explained")

**Intro Section:**
- Display `standard.shortDescription` as a prominent intro paragraph
- Display `standard.longDescription` in a styled block (human, simple language)
- Explain what Eurocode 1 defines, why loads are fundamental, and how loads affect foundations, slabs, and reinforcement

**Section: "What Eurocode 1 Covers"**
- Create a new section with heading "What Eurocode 1 Covers"
- Use conceptual blocks in plain language (NO formulas):
  - **Permanent loads (self-weight of structures):** Explain that these are the constant weights of the structure itself—concrete, steel, walls, floors. These don't change over time.
  - **Variable loads (people, furniture, vehicles):** Explain these are temporary loads that change—occupants, furniture, vehicles, equipment. These vary based on use.
  - **Snow loads:** Explain how snow accumulation on roofs and structures creates additional weight that must be considered.
  - **Wind loads:** Explain how wind pressure and suction forces act on structures, especially important for tall buildings and exposed structures.
  - **Combination of actions:** Explain that standards define HOW loads are classified and combined, not just numbers. Multiple loads act simultaneously, and standards provide rules for combining them safely.
- Emphasize that standards define HOW loads are classified and combined, not just numbers
- NO formulas from the standard, only concepts explained in plain language

**Section: "Why Loads Matter in Practice"**
- Heading: "Why Loads Matter in Practice"
- Explain in practical terms (cause → effect):
  - **Loads determine foundation size:** Heavier loads require larger, deeper foundations to distribute weight safely to the ground.
  - **Loads affect slab thickness:** Higher loads mean thicker concrete slabs to prevent cracking and deflection.
  - **Loads influence reinforcement amount:** More load means more steel reinforcement is needed to carry the forces safely.
- Use cause → effect explanations only
- NO formulas from the standard

**Section: "Calculations You Can Estimate"**
- Heading: "Calculations You Can Estimate"
- Explain how users typically estimate early-stage values:
  - **Areas and volumes:** Basic geometry calculations for foundation and slab dimensions
  - **Material quantities:** Estimating concrete, cement, and aggregate needs based on volumes
  - **Reinforcement weight:** Calculating rebar quantity and weight for preliminary estimates
  - **Geometry-based sizing:** Using dimensions to estimate structural element sizes
- Emphasize: "These tools help with estimation, not final design."
- Bridge to calculators section

**Section: "Related Calculators"**
- Heading: "Related Calculators"
- Display calculators from `relatedCalculators` array
- For each calculator, show:
  - Calculator title as a link to `/${locale}/calculators/${calc.category}/${calc.slug}`
  - Contextual label explaining the load connection
  - Examples:
    - "Slab Foundation Calculator" - "Used to estimate slab size affected by loads"
    - "Foundation Volume Calculator" - "Load-dependent foundation sizing"
    - "Concrete Volume Calculator" - "Used for estimating concrete volume based on structural dimensions"
    - "Rebar Calculator" - "Used for estimating reinforcement quantity based on load requirements"
    - "Rebar Weight Calculator" - "Used for calculating total weight of reinforcement bars"
    - "Stair Calculator" - "Live load relevance for stair design"

**Section: "Related Learn Articles"**
- Heading: "Related Learn Articles"
- Create placeholder links (even if articles don't exist yet):
  - "What Are Structural Loads?" → `/${locale}/learn/what-are-structural-loads`
  - "Dead Load vs Live Load Explained" → `/${locale}/learn/dead-load-vs-live-load-explained`
  - "Why Foundations Depend on Loads" → `/${locale}/learn/why-foundations-depend-on-loads`
- Style as simple text links with hover effects
- Note: Articles can be simple explanatory pieces

**Disclaimer Section (MANDATORY):**
- Create a prominent disclaimer block with:
  - Background: yellow/amber (e.g., `bg-yellow-50 border-yellow-200`)
  - Clear text:
    - "⚠️ Important: Calculators provide estimation only."
    - "Eurocode load combinations are not fully implemented in these tools."
    - "Always consult a qualified structural engineer for structural design."
    - "This page is an educational resource, not a substitute for professional engineering design."
    - "Load calculations must follow local building codes and regulations."

---

## 3. UPDATE METADATA

**File:** `app/[locale]/(main)/standards/[country]/[standardSlug]/page.tsx`

In `generateMetadata` function, ensure:
- **title:** "Eurocode 1 (EN 1991) – Structural Loads in Construction Explained"
- **description:** "Learn how Eurocode 1 defines structural loads and how load principles relate to foundation, slab, and reinforcement calculations."

---

## 4. UPDATE SCHEMA

**File:** `components/schema/standard-schema.tsx`

Ensure the schema for Eurocode 1 includes:
- **@type:** "TechArticle"
- **about:** Array or string including:
  - "structural loads"
  - "actions on structures"
- **isPartOf:** Reference to Standards portal (if schema supports it)

---

## 5. INTERNAL LINKING STRATEGY

**Note for future implementation:** From related calculator pages, add contextual links:

- **From Slab Foundation Calculator:** Add block "Load assumptions are described in Eurocode 1" linking to `/standards/eu/eurocode-1`
- **From Foundation Volume Calculator:** Add block "Load assumptions are described in Eurocode 1" linking to `/standards/eu/eurocode-1`
- **From Rebar Calculator:** Add block "Load assumptions are described in Eurocode 1" linking to `/standards/eu/eurocode-1`

**Important:** 
- Use phrasing: "Load assumptions are described in Eurocode 1"
- Do NOT claim compliance
- Use `rel="nofollow"` set to `false` (default, so no need to add nofollow attribute)

This will be implemented when updating calculator pages, but document this requirement.

---

## 6. STYLING REQUIREMENTS

- Use existing Tailwind classes from the codebase
- Follow the existing design patterns in `app/[locale]/(main)/standards/[country]/[standardSlug]/page.tsx`
- Use `bg-blue-50 border-blue-200` for related calculators section (already in use)
- Use `bg-yellow-50 border-yellow-200` for disclaimer
- Use `bg-white rounded-lg shadow-sm border border-gray-200 p-6` for content sections
- Maintain consistent spacing with `mb-8` between sections

---

## 7. IMPLEMENTATION CHECKLIST

- [ ] Update `data/standards.ts` - Eurocode 1 entry (EN locale)
- [ ] Verify standard page component detects hub pages (no formulas/tables)
- [ ] Add "What Eurocode 1 Covers" section with conceptual blocks
- [ ] Add "Why Loads Matter in Practice" section with cause → effect explanations
- [ ] Add "Calculations You Can Estimate" section with emphasis on estimation
- [ ] Update "Related Calculators" section with contextual labels
- [ ] Add "Related Learn Articles" section with placeholder links
- [ ] Add mandatory disclaimer section
- [ ] Update metadata (title and description)
- [ ] Verify schema includes structural loads and actions on structures
- [ ] Test page renders correctly at `/en/standards/eu/eurocode-1`
- [ ] Ensure all calculator links work
- [ ] Verify breadcrumbs work correctly

---

## 8. CONTENT GUIDELINES

- Write in clear, accessible English
- Focus on engineering context and practical understanding
- Explain concepts, don't just list them
- Use cause → effect language ("Loads determine...", "Loads affect...")
- Avoid technical jargon where possible
- Use active voice
- Keep paragraphs short (2-3 sentences)
- Use bullet points for lists
- Make it educational, not legal/regulatory
- Emphasize that this is about understanding concepts, not implementing the full standard

---

## 9. KEY DIFFERENCES FROM EUROCODE 2

- **Focus:** Eurocode 1 is about LOADS (inputs), Eurocode 2 is about CONCRETE (materials and design)
- **Purpose:** This page explains WHY loads matter, not HOW to calculate them
- **Connection:** Emphasize how load assumptions connect to foundation and slab sizing
- **Tone:** More conceptual, less material-focused
- **Calculators:** Include stair calculator (live load relevance) which wasn't in Eurocode 2

---

## NOTES

- This is an ENGINEERING CONTEXT HUB, not a technical reference
- Do NOT copy formulas or tables from Eurocode 1 standard
- Focus on explaining load concepts and connecting them to practical tools
- The page should help users understand what structural loads are and why they matter
- Always include the disclaimer prominently
- Do NOT claim compliance with Eurocode 1
- Emphasize estimation vs. final design throughout

