# PROMPT: Create Eurocode 2 Hub Page

## TASK OVERVIEW
Create a hub page for Eurocode 2 (EN 1992 – Concrete Structures) at `/standards/eu/eurocode-2`. This is a HUB page, not a legal document. It should explain what Eurocode 2 is, show related calculations, and link users to calculators and Learn articles.

## TARGET URL
`/standards/eu/eurocode-2`

## CATEGORY
Standards → Construction

---

## 1. UPDATE STANDARD DEFINITION

**File:** `data/standards.ts`

Update the existing Eurocode 2 entry (id: 'eurocode-2', country: 'EU', locale: 'en') with:

- **title:** "Eurocode 2 (EN 1992) – Concrete Structures Explained"
- **shortDescription:** "Learn what Eurocode 2 covers and how its principles relate to concrete, foundation, and reinforcement calculations."
- **longDescription:** A comprehensive hub-style description explaining:
  - What Eurocode 2 is (European standard for concrete structure design)
  - Who uses it (structural engineers, construction professionals)
  - What types of calculations it influences (volume, materials, reinforcement)
  - That this page is an educational hub, not a legal document
- **Remove formulas and tables** (set to empty arrays or undefined) - this is a hub, not a technical reference
- **relatedCalculatorIds:** Add these calculator IDs:
  - "concrete-volume-calculator"
  - "cement-calculator"
  - "concrete-mix-ratio-calculator"
  - "foundation-volume-calculator"
  - "slab-foundation-calculator"
  - "rebar-calculator"
  - "rebar-weight-calculator"
- **meta.keywords:** Include: ["eurocode 2", "EN 1992", "concrete structures", "concrete design", "reinforcement", "foundation design", "construction standards"]

---

## 2. UPDATE STANDARD PAGE COMPONENT

**File:** `app/[locale]/(main)/standards/[country]/[standardSlug]/page.tsx`

Modify the page to detect hub-style standards (those without formulas/tables) and render hub content instead of technical formulas/tables.

### Hub Page Structure:

**H1:** Use `standard.title` (already set to "Eurocode 2 (EN 1992) – Concrete Structures Explained")

**Intro Section:**
- Display `standard.shortDescription` as a prominent intro paragraph
- Display `standard.longDescription` in a styled block (human, simple language)

**Section: "What Eurocode 2 Covers"**
- Create a new section with heading "What Eurocode 2 Covers"
- Use bulleted blocks (not copied text from standard):
  - Concrete materials (properties, strength classes, durability)
  - Structural concrete elements (beams, columns, slabs, foundations)
  - Reinforcement principles (design, spacing, cover requirements)
  - Durability and safety concepts (service life, fire resistance, structural safety)
- NO formulas from the standard, only concepts explained in plain language

**Section: "Calculations in Practice"**
- Heading: "Calculations in Practice"
- Explain in plain language:
  - Volume calculations (why they matter for material ordering)
  - Material estimation (cement, aggregates, water)
  - Reinforcement estimation (rebar quantity, spacing, weight)
  - Why standards define assumptions (safety factors, design principles)
- This section bridges to calculators

**Section: "Related Calculators"**
- Heading: "Related Calculators"
- Display calculators from `relatedCalculators` array
- For each calculator, show:
  - Calculator title as a link to `/${locale}/calculators/${calc.category}/${calc.slug}`
  - Short explanatory note: "Used for estimating [purpose]"
  - Examples:
    - "Concrete Volume Calculator" - "Used for estimating concrete volume for slabs, footings, and columns"
    - "Cement Calculator" - "Used for estimating cement quantity based on concrete volume and mix ratio"
    - "Concrete Mix Ratio Calculator" - "Used for determining proper mix proportions for different concrete grades"
    - "Foundation Volume Calculator" - "Used for estimating concrete volume for various foundation types"
    - "Slab Foundation Calculator" - "Used for calculating slab foundation dimensions and material requirements"
    - "Rebar Calculator" - "Used for estimating reinforcement quantity and spacing for concrete slabs"
    - "Rebar Weight Calculator" - "Used for calculating total weight of reinforcement bars"

**Section: "Related Learn Articles"**
- Heading: "Related Learn Articles"
- Create placeholder links (even if articles don't exist yet):
  - "Concrete Basics for Construction" → `/${locale}/learn/concrete-basics-for-construction`
  - "How Reinforcement Is Estimated" → `/${locale}/learn/how-reinforcement-is-estimated`
  - "Concrete Foundations Explained" → `/${locale}/learn/concrete-foundations-explained`
- Style as simple text links with hover effects

**Disclaimer Section (MANDATORY):**
- Create a prominent disclaimer block with:
  - Background: yellow/amber (e.g., `bg-yellow-50 border-yellow-200`)
  - Clear text:
    - "⚠️ Important: This is an estimation tool and educational resource."
    - "This page is not a substitute for professional engineering design."
    - "Always consult qualified structural engineers and local building regulations for actual construction projects."
    - "Eurocode 2 compliance requires professional design verification."

---

## 3. UPDATE METADATA

**File:** `app/[locale]/(main)/standards/[country]/[standardSlug]/page.tsx`

In `generateMetadata` function, ensure:
- **title:** "Eurocode 2 (EN 1992) – Concrete Structure Calculations Explained"
- **description:** "Learn what Eurocode 2 covers and how its principles relate to concrete, foundation, and reinforcement calculations."

---

## 4. UPDATE SCHEMA

**File:** `components/schema/standard-schema.tsx`

Ensure the schema for Eurocode 2 includes:
- **@type:** "TechArticle"
- **about:** "Concrete structures" (or use standard.country if that's the pattern)
- **isPartOf:** Reference to Standards portal (if schema supports it)

---

## 5. INTERNAL LINKING STRATEGY

**Note for future implementation:** From each related calculator page, add a block "Based on Eurocode 2 principles" linking back to `/standards/eu/eurocode-2` with `rel="nofollow"` set to `false` (default, so no need to add nofollow attribute).

This will be implemented when updating calculator pages, but document this requirement.

---

## 6. STYLING REQUIREMENTS

- Use existing Tailwind classes from the codebase
- Follow the existing design patterns in `app/[locale]/(main)/standards/[country]/[standardSlug]/page.tsx`
- Use `bg-blue-50 border-blue-200` for related calculators section (already in use)
- Use `bg-yellow-50 border-yellow-200` for disclaimer
- Use `bg-white rounded-lg shadow-sm border border-gray-200 p-6` for content sections
- Maintain consistent spacing with `mb-8` between sections

---

## 7. IMPLEMENTATION CHECKLIST

- [ ] Update `data/standards.ts` - Eurocode 2 entry (EN locale)
- [ ] Modify standard page component to detect hub pages (no formulas/tables)
- [ ] Add "What Eurocode 2 Covers" section with bulleted concepts
- [ ] Add "Calculations in Practice" section with plain language explanations
- [ ] Update "Related Calculators" section with explanatory notes
- [ ] Add "Related Learn Articles" section with placeholder links
- [ ] Add mandatory disclaimer section
- [ ] Update metadata (title and description)
- [ ] Verify schema is correct
- [ ] Test page renders correctly at `/en/standards/eu/eurocode-2`
- [ ] Ensure all calculator links work
- [ ] Verify breadcrumbs work correctly

---

## 8. CONTENT GUIDELINES

- Write in clear, accessible English
- Avoid technical jargon where possible
- Explain concepts, don't just list them
- Use active voice
- Keep paragraphs short (2-3 sentences)
- Use bullet points for lists
- Make it educational, not legal/regulatory

---

## NOTES

- This is a HUB page, not a technical reference
- Do NOT copy formulas or tables from Eurocode 2 standard
- Focus on explaining concepts and linking to practical tools
- The page should help users understand what Eurocode 2 is and how to use related calculators
- Always include the disclaimer prominently

