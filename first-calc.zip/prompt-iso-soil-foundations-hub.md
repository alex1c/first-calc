# PROMPT: Create ISO Soil & Geotechnical Hub Page

## TASK OVERVIEW
Create a geotechnical context hub page for ISO Soil & Geotechnical Basics (Foundations and Ground Conditions) at `/standards/iso/soil-and-foundations`. This page is a GEOTECHNICAL CONTEXT HUB that explains how soil properties affect foundations, introduces geotechnical concepts in simple language, and connects soil assumptions to foundation and pile calculators. This is NOT a soil mechanics textbook—it is an explanatory bridge between soil and construction calculations.

## TARGET URL
`/standards/iso/soil-and-foundations`

## CATEGORY
Standards → Construction

---

## 1. CREATE NEW STANDARD DEFINITION

**File:** `data/standards.ts`

Add a new ISO standard entry (this is a NEW standard, not updating an existing one):

```typescript
// ISO Soil & Geotechnical Basics (EN)
{
	id: 'iso-soil-foundations',
	country: 'ISO',
	slug: 'soil-and-foundations',
	locale: 'en',
	title: 'Soil and Foundation Basics – ISO Geotechnical Principles Explained',
	shortDescription:
		'Learn how soil properties affect foundations and how geotechnical principles relate to foundation, pile, and concrete calculations.',
	longDescription:
		'Geotechnical standards describe how soil properties influence foundation design. This page explains why the same building needs different foundations on different soils, how standards describe soil behavior and classification, and how soil assumptions connect to practical foundation calculations. This is an educational resource that bridges soil mechanics concepts with construction calculations.',
	formulas: undefined, // No formulas - this is a hub
	tables: undefined, // No tables - this is a hub
	relatedCalculatorIds: [
		'foundation-volume-calculator',
		'strip-foundation-calculator',
		'slab-foundation-calculator',
		'pile-foundation-calculator',
		'concrete-volume-calculator',
		'rebar-calculator',
	],
	meta: {
		keywords: [
			'iso',
			'soil mechanics',
			'geotechnical engineering',
			'foundations',
			'bearing capacity',
			'settlement',
			'pile foundations',
			'ground conditions',
			'construction standards',
		],
		organization: 'ISO',
		year: null, // Multiple ISO standards cover this topic
	},
},
```

---

## 2. UPDATE STANDARD PAGE COMPONENT

**File:** `app/[locale]/(main)/standards/[country]/[standardSlug]/page.tsx`

The component should already support hub pages (from Eurocode 2 implementation). Verify it handles standards without formulas/tables correctly.

### Hub Page Structure:

**H1:** Use `standard.title` (set to "Soil and Foundation Basics – ISO Geotechnical Principles Explained")

**Intro Section:**
- Display `standard.shortDescription` as a prominent intro paragraph
- Display `standard.longDescription` in a styled block (human, simple language)
- Explain:
  - Why soil matters in construction
  - Why the same building needs different foundations on different soils
  - How standards describe soil behavior and classification

**Section: "What Geotechnical Standards Cover"**
- Create a new section with heading "What Geotechnical Standards Cover"
- Use conceptual blocks in plain language (NO formulas):
  - **Soil types (sand, clay, gravel, rock):** Explain the basic classification of soils and how different types behave differently under load. Sand drains well but can shift. Clay holds water and can expand/contract. Gravel is strong and stable. Rock provides the strongest foundation.
  - **Bearing capacity concepts:** Explain that bearing capacity is the soil's ability to support loads without failure. Strong soils can support more load per unit area. Standards define how to determine and use bearing capacity values.
  - **Settlement and deformation:** Explain that all soils compress under load—this is settlement. Some soils settle more than others. Standards provide guidance on acceptable settlement limits.
  - **Groundwater influence:** Explain how water in the ground affects soil behavior. High groundwater can reduce soil strength, cause frost heave, and require drainage systems.
  - **Safety factors and assumptions:** Explain that standards define safety factors to account for uncertainty in soil properties. These factors ensure foundations are designed conservatively.
- Emphasize: "Standards define HOW soils are classified and tested, not just numerical values."
- NO formulas from standards, only concepts explained in plain language

**Section: "How Soil Affects Foundations"**
- Heading: "How Soil Affects Foundations"
- Explain cause → effect relationships:
  - **Weak soil → larger foundations:** Weak soils cannot support much load per unit area, so foundations must be larger (wider, deeper) to spread the load over more soil area.
  - **Compressible soil → settlement risk:** Soils that compress easily (like soft clay) will settle more under load, requiring deeper foundations or special design considerations.
  - **Groundwater → drainage and design changes:** High groundwater levels can reduce soil strength, require waterproofing, and may need drainage systems or dewatering during construction.
  - **Piles used when shallow foundations are insufficient:** When soil near the surface is too weak, piles transfer loads to deeper, stronger soil layers or bedrock.
- Use bullet logic or simple cause → effect statements
- NO equations or formulas

**Section: "Calculations in Early-Stage Practice"**
- Heading: "Calculations in Early-Stage Practice"
- Explain what is commonly estimated BEFORE detailed soil reports:
  - **Foundation geometry:** Estimating foundation dimensions based on building loads and assumed soil conditions
  - **Concrete volume:** Calculating concrete needed for foundations based on estimated dimensions
  - **Pile quantity and size:** Estimating number and size of piles for preliminary design
  - **Reinforcement estimates:** Calculating approximate rebar quantities for foundation elements
- Emphasize: "Final design always requires geotechnical investigation."
- Bridge to calculators section

**Section: "Related Calculators"**
- Heading: "Related Calculators"
- Display calculators from `relatedCalculators` array
- For each calculator, show:
  - Calculator title as a link to `/${locale}/calculators/${calc.category}/${calc.slug}`
  - Short explanatory subtitle connecting to soil/geotechnical concepts
  - Examples:
    - "Foundation Volume Calculator" - "Foundation sizing depends on soil bearing capacity"
    - "Strip Foundation Calculator" - "Used for estimating continuous footing dimensions based on load and soil assumptions"
    - "Slab Foundation Calculator" - "Slab thickness and area depend on soil bearing capacity and settlement considerations"
    - "Pile Foundation Calculator" - "Pile design depends on soil conditions and load transfer requirements"
    - "Concrete Volume Calculator" - "Used for estimating concrete volume for foundation elements"
    - "Rebar Calculator" - "Used for estimating reinforcement quantity for foundation elements"

**Section: "Related Learn Articles"**
- Heading: "Related Learn Articles"
- Create placeholder links (even if articles don't exist yet):
  - "Basic Soil Types Explained" → `/${locale}/learn/basic-soil-types-explained`
  - "What Is Bearing Capacity?" → `/${locale}/learn/what-is-bearing-capacity`
  - "When to Use Pile Foundations" → `/${locale}/learn/when-to-use-pile-foundations`
  - "Why Soil Investigation Matters" → `/${locale}/learn/why-soil-investigation-matters`
- Style as simple text links with hover effects
- Note: Articles are explanatory, not normative

**Disclaimer Section (MANDATORY - STRONG):**
- Create a prominent disclaimer block with:
  - Background: red/amber (e.g., `bg-red-50 border-red-200` or `bg-yellow-50 border-yellow-300`)
  - Strong, clear text:
    - "⚠️ CRITICAL: Calculators are for estimation only."
    - "Soil properties cannot be assumed without proper geotechnical testing."
    - "Always consult qualified geotechnical engineers and local building regulations."
    - "Final foundation design requires site-specific soil investigation and professional engineering."
    - "This page is an educational resource, not a substitute for geotechnical engineering services."
- Make this disclaimer more prominent than other standard disclaimers due to safety implications

---

## 3. UPDATE METADATA

**File:** `app/[locale]/(main)/standards/[country]/[standardSlug]/page.tsx`

In `generateMetadata` function, ensure:
- **title:** "Soil and Foundation Basics – ISO Geotechnical Principles Explained"
- **description:** "Learn how soil properties affect foundations and how geotechnical principles relate to foundation, pile, and concrete calculations."

---

## 4. UPDATE SCHEMA

**File:** `components/schema/standard-schema.tsx`

Ensure the schema for this standard includes:
- **@type:** "TechArticle"
- **about:** Array or string including:
  - "soil mechanics"
  - "geotechnical engineering"
  - "foundations"
- **isPartOf:** Reference to Standards portal (if schema supports it)

---

## 5. INTERNAL LINKING STRATEGY

**Note for future implementation:** From related calculator pages, add contextual links:

- **From Foundation Volume Calculator:** Add block "Soil behavior principles are explained in ISO geotechnical standards" linking to `/standards/iso/soil-and-foundations`
- **From Strip Foundation Calculator:** Add block "Soil behavior principles are explained in ISO geotechnical standards" linking to `/standards/iso/soil-and-foundations`
- **From Slab Foundation Calculator:** Add block "Soil behavior principles are explained in ISO geotechnical standards" linking to `/standards/iso/soil-and-foundations`
- **From Pile Foundation Calculator:** Add block "Soil behavior principles are explained in ISO geotechnical standards" linking to `/standards/iso/soil-and-foundations`

**Important:** 
- Use wording: "Soil behavior principles are explained in ISO geotechnical standards"
- No compliance claims
- Use `rel="nofollow"` set to `false` (default, so no need to add nofollow attribute)

This will be implemented when updating calculator pages, but document this requirement.

---

## 6. STYLING REQUIREMENTS

- Use existing Tailwind classes from the codebase
- Follow the existing design patterns in `app/[locale]/(main)/standards/[country]/[standardSlug]/page.tsx`
- Use `bg-blue-50 border-blue-200` for related calculators section (already in use)
- Use `bg-red-50 border-red-200` or `bg-yellow-50 border-yellow-300` for disclaimer (stronger than other disclaimers)
- Use `bg-white rounded-lg shadow-sm border border-gray-200 p-6` for content sections
- Maintain consistent spacing with `mb-8` between sections

---

## 7. IMPLEMENTATION CHECKLIST

- [ ] Add new standard definition to `data/standards.ts` with id 'iso-soil-foundations'
- [ ] Verify standard page component handles hub pages correctly
- [ ] Add "What Geotechnical Standards Cover" section with 5 conceptual blocks
- [ ] Add "How Soil Affects Foundations" section with cause → effect explanations
- [ ] Add "Calculations in Early-Stage Practice" section with emphasis on geotechnical investigation
- [ ] Update "Related Calculators" section with geotechnical context labels
- [ ] Add "Related Learn Articles" section with 4 placeholder links
- [ ] Add strong mandatory disclaimer section (more prominent than other standards)
- [ ] Update metadata (title and description)
- [ ] Verify schema includes soil mechanics, geotechnical engineering, foundations
- [ ] Test page renders correctly at `/en/standards/iso/soil-and-foundations`
- [ ] Ensure all calculator links work
- [ ] Verify breadcrumbs work correctly
- [ ] Test that standard appears in ISO standards listing page

---

## 8. CONTENT GUIDELINES

- Write in clear, accessible English
- Focus on geotechnical context and practical understanding
- Explain concepts, don't just list them
- Use cause → effect language ("Weak soil → larger foundations", "Compressible soil → settlement risk")
- Avoid technical jargon where possible
- Use active voice
- Keep paragraphs short (2-3 sentences)
- Use bullet points for lists
- Make it educational, not normative
- Emphasize that this is about understanding concepts, not implementing full geotechnical design
- Stress the importance of professional geotechnical investigation

---

## 9. KEY DIFFERENCES FROM OTHER STANDARDS

- **Focus:** This is about SOIL and GROUND CONDITIONS, not structural loads or materials
- **Purpose:** Bridge between soil mechanics concepts and practical foundation calculations
- **Safety Emphasis:** Stronger disclaimer due to safety implications of incorrect foundation design
- **Connection:** Emphasize how soil properties connect to foundation sizing and type selection
- **Tone:** More educational, less technical—explaining WHY soil matters, not HOW to calculate it
- **Calculators:** Focus on foundation and pile calculators, less on materials

---

## 10. NOTES

- This is a GEOTECHNICAL CONTEXT HUB, not a soil mechanics textbook
- Do NOT copy formulas or tables from ISO geotechnical standards
- Focus on explaining soil concepts and connecting them to practical foundation tools
- The page should help users understand why soil matters and how it affects foundation design
- Always include the strong disclaimer prominently
- Do NOT claim compliance with ISO standards
- Emphasize estimation vs. final design throughout
- Stress that geotechnical investigation is always required for final design
- This page prepares users for deeper standards later (ISO / EN / national codes)

